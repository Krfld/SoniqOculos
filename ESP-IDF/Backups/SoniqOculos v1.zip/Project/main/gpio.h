#include "main.h"

void gpio_set(gpio_num_t pin, size_t level);

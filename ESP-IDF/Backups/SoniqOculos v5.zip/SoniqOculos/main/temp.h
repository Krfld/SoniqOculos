char *welcome_frmt = "mode:volume:devices:sd_state:bc_state";

char *welcome = "[0,1]:[0-100]:[0,1,2]:[0,1]:[0,1]";
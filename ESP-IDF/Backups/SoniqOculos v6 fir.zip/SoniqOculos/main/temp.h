char *setup_msg = "mode:volume:m_devices:m_equalizer:r_sd_state:r_bc_state";

#define OK "OK"

char *mode = "md [0,1]";

char *volume = "v [0..100]";

char *devices = "d [0,1,2]";

char *equalizer = "e b[0..100] m[0..100] t[0..100]";

char *sd_state = "sd [0,1]";

char *bc_state = "bc [0,1]";